/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_355(unsigned x)
{
    return x + 3285092680U;
}

unsigned getval_334()
{
    return 2447345992U;
}

unsigned getval_102()
{
    return 3750316102U;
}

unsigned addval_488(unsigned x)
{
    return x + 3344683625U;
}

unsigned getval_410()
{
    return 2425393243U;
}

unsigned addval_164(unsigned x)
{
    return x + 3281031258U;
}

void setval_400(unsigned *p)
{
    *p = 3285256520U;
}

void setval_219(unsigned *p)
{
    *p = 3465101440U;
}

unsigned getval_262()
{
    return 3352398152U;
}

void setval_304(unsigned *p)
{
    *p = 3286206792U;
}

unsigned getval_498()
{
    return 2447345992U;
}

unsigned addval_194(unsigned x)
{
    return x + 2446231880U;
}

void setval_167(unsigned *p)
{
    *p = 3352953160U;
}

unsigned getval_283()
{
    return 2429651272U;
}

void setval_118(unsigned *p)
{
    *p = 3657517059U;
}

void setval_111(unsigned *p)
{
    *p = 2425379342U;
}

unsigned addval_343(unsigned x)
{
    return x + 2425393370U;
}

unsigned addval_134(unsigned x)
{
    return x + 2425394267U;
}

void setval_338(unsigned *p)
{
    *p = 2429454664U;
}

unsigned addval_424(unsigned x)
{
    return x + 3657517187U;
}

unsigned addval_198(unsigned x)
{
    return x + 2497315144U;
}

void setval_391(unsigned *p)
{
    *p = 3285289288U;
}

unsigned addval_114(unsigned x)
{
    return x + 2455377314U;
}

unsigned addval_347(unsigned x)
{
    return x + 3281031259U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
